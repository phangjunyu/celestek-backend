from flask import Flask, request, make_response, jsonify
from datetime import datetime, timedelta
from time import strftime


app = Flask(__name__)

def generate_date():
	current_date = datetime.today()
	month_ago = current_date - timedelta(days = 30)
	current_date = current_date.strftime("%Y-%m-%dT%H:%M:%S.000Z")
	month_ago = month_ago.strftime("%Y-%m-%dT%H:%M:%S.000Z")
	return current_date, month_ago


@app.route("/")
def hello():
    return "Hello SpaceView!"


@app.route('/test/', methods=['GET', 'POST'])
def downloadAndUploadImagesToS3():
    if request.method == 'POST':
	    return make_response("POST SPACEVIEW", 200)
    else:
	    return make_response("GET SPACEVIEW", 200)

@app.route('/getImageURLs/', methods=['POST'])
def superfunction():

	data = request.get_json()

	coordinates = data['nameValuePairs']['coordinates']
	print(coordinates)
	current_date, month_ago = generate_date()
	from image_filters import filter
	filter.set_coordinates(coordinates)
	filter.set_dates(current_date, month_ago)
	import get_images
	get_images.mainfunction()
	return "SUCCESS"



if __name__ == '__main__':
    app.run(debug=True)
